// =====================================================================
// EDIT THIS FILE to change company details, services, departments,
// statistics, opening hours and sample doctors. Anything marked
// "ADD_..." or "PLACEHOLDER" is NOT real information yet.
// =====================================================================

export const siteConfig = {
  name: "Medi Life",
  tagline: "Better Health. Brighter Tomorrow.",
  description:
    "Compassionate healthcare, modern medical services, and patient-focused care designed around your health and wellbeing.",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",
  phone: "ADD_PHONE",
  email: "ADD_EMAIL",
  address: "ADD_ADDRESS",
  emergency: "ADD_EMERGENCY_NUMBER",
  hours: [
    { day: "Monday - Friday", time: "ADD_HOURS" },
    { day: "Saturday", time: "ADD_HOURS" },
    { day: "Sunday", time: "ADD_HOURS" },
  ],
  // Replace "#" with real profile URLs. Icons with "#" are hidden automatically.
  social: { facebook: "#", instagram: "#", linkedin: "#", youtube: "#" },
};

// Replace these placeholders with real numbers before launch.
export const stats = [
  { label: "Years of Experience", value: "ADD" },
  { label: "Medical Professionals", value: "ADD" },
  { label: "Patients Served", value: "ADD" },
  { label: "Healthcare Services", value: "ADD" },
];

export type Service = { slug: string; name: string; icon: string; description: string; points: string[] };

// Confirm which services Medi Life really offers; delete the rest.
export const services: Service[] = [
  { slug: "general-medicine", name: "General Medicine", icon: "stethoscope", description: "Everyday consultations and ongoing care for adults.", points: ["Health check-ups", "Common illness care", "Referrals to specialists"] },
  { slug: "cardiology", name: "Cardiology", icon: "heart", description: "Care focused on heart and circulation health.", points: ["Heart health consultations", "Follow-up care"] },
  { slug: "gynecology", name: "Gynecology", icon: "flower", description: "Women's health consultations and care.", points: ["Women's health consultations", "Follow-up care"] },
  { slug: "pediatrics", name: "Pediatrics", icon: "baby", description: "Gentle healthcare for infants, children and teens.", points: ["Child health consultations", "Growth and development"] },
  { slug: "orthopedics", name: "Orthopedics", icon: "bone", description: "Care for bones, joints and mobility.", points: ["Joint and bone consultations", "Follow-up care"] },
  { slug: "dermatology", name: "Dermatology", icon: "sparkles", description: "Skin, hair and nail care.", points: ["Skin consultations", "Follow-up care"] },
  { slug: "diagnostics", name: "Diagnostics", icon: "scan", description: "Tests that help doctors reach clear answers.", points: ["Diagnostic testing", "Result consultations"] },
  { slug: "laboratory-services", name: "Laboratory Services", icon: "flask", description: "Laboratory testing to support diagnosis and monitoring.", points: ["Sample collection", "Test reports"] },
  { slug: "radiology", name: "Radiology", icon: "scan", description: "Imaging services to support diagnosis.", points: ["Imaging services", "Report review"] },
  { slug: "emergency-care", name: "Emergency Care", icon: "siren", description: "Urgent medical attention when it matters most.", points: ["Urgent care", "Emergency contact line"] },
  { slug: "preventive-healthcare", name: "Preventive Healthcare", icon: "shield", description: "Screenings and advice to help you stay well.", points: ["Screenings", "Lifestyle guidance"] },
  { slug: "health-consultations", name: "Health Consultations", icon: "message", description: "Talk to a professional about your health concerns.", points: ["In-person consultations", "Care planning"] },
];

export type Department = { slug: string; name: string; icon: string; description: string; services: string[] };

export const departments: Department[] = [
  { slug: "general-medicine", name: "General Medicine", icon: "stethoscope", description: "First point of contact for most health concerns.", services: ["Consultations", "Check-ups", "Referrals"] },
  { slug: "cardiology", name: "Cardiology", icon: "heart", description: "Heart and circulation care.", services: ["Consultations", "Follow-up care"] },
  { slug: "gynecology", name: "Gynecology", icon: "flower", description: "Women's health care.", services: ["Consultations", "Follow-up care"] },
  { slug: "pediatrics", name: "Pediatrics", icon: "baby", description: "Care for children and teens.", services: ["Consultations", "Child wellness"] },
  { slug: "orthopedics", name: "Orthopedics", icon: "bone", description: "Bone and joint care.", services: ["Consultations", "Follow-up care"] },
  { slug: "dermatology", name: "Dermatology", icon: "sparkles", description: "Skin, hair and nail care.", services: ["Consultations", "Follow-up care"] },
  { slug: "diagnostics", name: "Diagnostics & Radiology", icon: "scan", description: "Laboratory and imaging support.", services: ["Laboratory", "Imaging"] },
  { slug: "emergency-care", name: "Emergency Care", icon: "siren", description: "Urgent medical attention.", services: ["Urgent care"] },
];

export type Doctor = { id: string; name: string; specialty: string; qualification: string; experience: string; availability: string; image_url: string | null; bio: string };

// SAMPLE ONLY. These are not real doctors. Real doctors are loaded from the
// Supabase "doctors" table (add them in /admin). This list is a fallback.
export const sampleDoctors: Doctor[] = [
  { id: "sample-1", name: "ADD_DOCTOR_NAME", specialty: "General Medicine", qualification: "ADD_QUALIFICATION", experience: "ADD_YEARS", availability: "ADD_AVAILABILITY", image_url: null, bio: "ADD_BIO" },
  { id: "sample-2", name: "ADD_DOCTOR_NAME", specialty: "Pediatrics", qualification: "ADD_QUALIFICATION", experience: "ADD_YEARS", availability: "ADD_AVAILABILITY", image_url: null, bio: "ADD_BIO" },
  { id: "sample-3", name: "ADD_DOCTOR_NAME", specialty: "Cardiology", qualification: "ADD_QUALIFICATION", experience: "ADD_YEARS", availability: "ADD_AVAILABILITY", image_url: null, bio: "ADD_BIO" },
];

export const values = [
  { title: "Patient First", text: "Every decision starts with what is best for the patient." },
  { title: "Integrity", text: "Honest communication and ethical practice." },
  { title: "Compassion", text: "Care that treats people with kindness and respect." },
  { title: "Excellence", text: "A steady commitment to high-quality care." },
  { title: "Safety", text: "Safe, clean and careful care at every step." },
  { title: "Innovation", text: "Using modern tools to improve care." },
];

export const faqs = [
  { q: "How do I book an appointment?", a: "Use the Book an Appointment page, choose a department, date and time, and send the form. Our team will confirm with you." },
  { q: "Is this website for medical emergencies?", a: "No. In an emergency, call your local emergency number or go to the nearest emergency department immediately." },
  { q: "What are your opening hours?", a: "ADD_HOURS. See the Contact page for current hours." },
  { q: "Which services do you offer?", a: "See the Services page for the current list. For anything not listed, contact us." },
  { q: "How will my information be used?", a: "Details you send are used only to respond to your request. ADD_PRIVACY_POLICY_LINK." },
];

export const posts = [
  { slug: "preparing-for-your-visit", title: "Preparing for your doctor's visit", excerpt: "A few simple steps to get the most from your appointment.", body: ["PLACEHOLDER ARTICLE. Replace this text with a reviewed medical article.", "Bring a list of your questions, current medicines and any previous reports."] },
  { slug: "everyday-preventive-care", title: "Everyday habits for better health", excerpt: "Small, steady habits that support long-term wellbeing.", body: ["PLACEHOLDER ARTICLE. Replace this text with a reviewed medical article.", "This content is general information and not a substitute for professional medical advice."] },
  { slug: "when-to-see-a-doctor", title: "When should you see a doctor?", excerpt: "Signs that it is time to book a consultation.", body: ["PLACEHOLDER ARTICLE. Replace this text with a reviewed medical article.", "If you think you are having an emergency, contact emergency services immediately."] },
];

export const navLinks = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/services", label: "Services" },
  { href: "/departments", label: "Departments" },
  { href: "/doctors", label: "Doctors" },
  { href: "/quality", label: "Quality" },
  { href: "/blog", label: "Blog" },
  { href: "/contact", label: "Contact" },
];
