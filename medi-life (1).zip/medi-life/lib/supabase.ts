import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";

export const isSupabaseConfigured = Boolean(url && anon);

// Only the public anon key is used. Row Level Security (see supabase/schema.sql)
// controls what visitors and admins can do. Never put a service-role key here.
export const supabase = createClient(url || "http://localhost:54321", anon || "public-anon-key");
