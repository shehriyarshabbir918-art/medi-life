import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: { DEFAULT: "#006EDF", dark: "#0058B3", light: "#E6F4FF" },
        mint: { DEFAULT: "#10B981", dark: "#0B8F63" },
        ink: "#123B63",
        mist: "#F7FBFF",
      },
      fontFamily: { sans: ["var(--font-sans)", "system-ui", "sans-serif"] },
      boxShadow: { soft: "0 10px 30px -12px rgba(0,110,223,0.18)" },
    },
  },
  plugins: [],
};
export default config;
