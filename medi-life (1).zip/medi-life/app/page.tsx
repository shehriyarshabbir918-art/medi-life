import Link from "next/link";
import { HeartHandshake, Stethoscope, Building2, BadgeCheck } from "lucide-react";
import ServiceCard from "@/components/ServiceCard";
import ImagePlaceholder from "@/components/ImagePlaceholder";
import Cta from "@/components/Cta";
import { siteConfig, services, stats } from "@/lib/siteConfig";

const why = [
  { Icon: Stethoscope, title: "Experienced Healthcare Professionals", text: "A dedicated team focused on careful, accurate care." },
  { Icon: HeartHandshake, title: "Patient-Centered Care", text: "We listen first and plan care around you." },
  { Icon: Building2, title: "Modern Medical Facilities", text: "Comfortable, well-equipped spaces for your visit." },
  { Icon: BadgeCheck, title: "Trusted Healthcare Services", text: "Clear communication and honest guidance." },
];
const previewSlugs = ["general-medicine", "cardiology", "gynecology", "pediatrics", "orthopedics", "dermatology", "diagnostics", "radiology", "emergency-care"];

export default function Home() {
  const preview = services.filter((s) => previewSlugs.includes(s.slug));
  return (
    <>
      <section className="bg-gradient-to-br from-brand-light via-mist to-white">
        <div className="container-x grid items-center gap-10 py-14 sm:py-20 lg:grid-cols-2">
          <div className="rise">
            <h1 className="text-4xl font-extrabold leading-tight tracking-tight sm:text-5xl lg:text-6xl">{siteConfig.tagline}</h1>
            <p className="mt-5 max-w-lg text-lg text-ink/75">{siteConfig.description}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link href="/appointment" className="btn-primary">Book an Appointment</Link>
              <Link href="/services" className="btn-outline">Explore Our Services</Link>
            </div>
          </div>
          <div className="h-[320px] sm:h-[420px]"><ImagePlaceholder alt="Medi Life care team with a patient" label="hero photo (e.g. /images/hero.jpg)" className="!h-full" /></div>
        </div>
      </section>

      <section className="section">
        <div className="container-x">
          <h2 className="text-3xl font-extrabold sm:text-4xl">Why Choose Medi Life</h2>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {why.map(({ Icon, title, text }) => (
              <div key={title} className="card">
                <span className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-mint/10 text-mint-dark"><Icon size={24} aria-hidden="true" /></span>
                <h3 className="font-bold">{title}</h3>
                <p className="mt-2 text-sm text-ink/70">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-mist">
        <div className="container-x">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <h2 className="text-3xl font-extrabold sm:text-4xl">Our Services</h2>
            <Link href="/services" className="btn-outline">View all services</Link>
          </div>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{preview.map((s) => <ServiceCard key={s.slug} service={s} />)}</div>
        </div>
      </section>

      <section className="section">
        <div className="container-x">
          <dl className="grid grid-cols-2 gap-6 lg:grid-cols-4">
            {stats.map((s) => (
              <div key={s.label} className="rounded-3xl bg-brand-light p-6 text-center">
                <dd className="text-4xl font-extrabold text-brand">{s.value}</dd>
                <dt className="mt-1 text-sm font-medium">{s.label}</dt>
              </div>
            ))}
          </dl>
          <p className="mt-3 text-center text-xs text-ink/50">Placeholder numbers. Edit them in lib/siteConfig.ts.</p>
        </div>
      </section>
      <Cta />
    </>
  );
}
