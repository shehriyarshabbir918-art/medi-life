import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import PageHeader from "@/components/PageHeader";
import { services } from "@/lib/siteConfig";

export function generateStaticParams() { return services.map((s) => ({ slug: s.slug })); }
export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const s = services.find((x) => x.slug === params.slug);
  return { title: s?.name ?? "Service", description: s?.description };
}

export default function ServiceDetail({ params }: { params: { slug: string } }) {
  const s = services.find((x) => x.slug === params.slug);
  if (!s) notFound();
  return (
    <>
      <PageHeader title={s.name} text={s.description} />
      <section className="section"><div className="container-x max-w-3xl">
        <h2 className="text-2xl font-extrabold">What this includes</h2>
        <ul className="mt-4 list-disc space-y-2 pl-6">{s.points.map((p) => <li key={p}>{p}</li>)}</ul>
        <p className="mt-6 rounded-2xl bg-brand-light p-4 text-sm text-ink/70">Placeholder: confirm the exact details of this service before launch.</p>
        <div className="mt-8 flex flex-wrap gap-3"><Link href="/appointment" className="btn-primary">Book an Appointment</Link><Link href="/services" className="btn-outline">All services</Link></div>
      </div></section>
    </>
  );
}
