import type { Metadata } from "next";
import PageHeader from "@/components/PageHeader";
import ServiceCard from "@/components/ServiceCard";
import Cta from "@/components/Cta";
import { services } from "@/lib/siteConfig";

export const metadata: Metadata = { title: "Healthcare Services", description: "Explore healthcare services at Medi Life." };

export default function Services() {
  return (
    <>
      <PageHeader title="Healthcare Services" text="Care for every stage of life, from check-ups to specialist support." />
      <section className="section"><div className="container-x grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{services.map((s) => <ServiceCard key={s.slug} service={s} />)}</div></section>
      <Cta />
    </>
  );
}
