import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import PageHeader from "@/components/PageHeader";
import { departments } from "@/lib/siteConfig";

export function generateStaticParams() { return departments.map((d) => ({ slug: d.slug })); }
export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const d = departments.find((x) => x.slug === params.slug);
  return { title: d?.name ?? "Department", description: d?.description };
}

export default function DepartmentDetail({ params }: { params: { slug: string } }) {
  const d = departments.find((x) => x.slug === params.slug);
  if (!d) notFound();
  return (
    <>
      <PageHeader title={d.name} text={d.description} />
      <section className="section"><div className="container-x max-w-3xl">
        <h2 className="text-2xl font-extrabold">Services offered</h2>
        <ul className="mt-4 list-disc space-y-2 pl-6">{d.services.map((s) => <li key={s}>{s}</li>)}</ul>
        <p className="mt-6 rounded-2xl bg-brand-light p-4 text-sm text-ink/70">Placeholder: confirm this department&apos;s details before launch.</p>
        <div className="mt-8 flex flex-wrap gap-3"><Link href="/appointment" className="btn-primary">Book an Appointment</Link><Link href="/departments" className="btn-outline">All departments</Link></div>
      </div></section>
    </>
  );
}
