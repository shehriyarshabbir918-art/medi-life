import type { Metadata } from "next";
import PageHeader from "@/components/PageHeader";
import DepartmentCard from "@/components/DepartmentCard";
import Cta from "@/components/Cta";
import { departments } from "@/lib/siteConfig";

export const metadata: Metadata = { title: "Medical Departments", description: "Browse Medi Life medical departments." };

export default function Departments() {
  return (
    <>
      <PageHeader title="Medical Departments" text="Find the right department for your care." />
      <section className="section"><div className="container-x grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{departments.map((d) => <DepartmentCard key={d.slug} dept={d} />)}</div></section>
      <Cta />
    </>
  );
}
