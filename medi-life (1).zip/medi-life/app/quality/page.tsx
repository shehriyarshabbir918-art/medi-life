import type { Metadata } from "next";
import { ShieldCheck, Sparkles, ClipboardCheck, Lock } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import Cta from "@/components/Cta";

export const metadata: Metadata = { title: "Quality & Safety", description: "How Medi Life approaches quality and patient safety." };

const items = [
  { Icon: ShieldCheck, title: "Patient safety", text: "Safety comes before speed, in every part of care." },
  { Icon: Sparkles, title: "Cleanliness", text: "Clean, well-kept spaces for patients and staff." },
  { Icon: ClipboardCheck, title: "Clear processes", text: "Consistent steps so care is reliable." },
  { Icon: Lock, title: "Privacy", text: "Patient information is handled with care." },
];

export default function Quality() {
  return (
    <>
      <PageHeader title="Quality & Safety" text="Our commitment to safe, dependable care." />
      <section className="section"><div className="container-x">
        <div className="grid gap-6 sm:grid-cols-2">{items.map(({ Icon, title, text }) => (
          <div key={title} className="card"><span className="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-mint/10 text-mint-dark"><Icon size={24} aria-hidden="true" /></span><h2 className="font-bold">{title}</h2><p className="mt-2 text-sm text-ink/70">{text}</p></div>
        ))}</div>
        <p className="mt-8 rounded-2xl bg-brand-light p-4 text-sm text-ink/70">Placeholder: add certifications, accreditations and approvals here only after they are verified.</p>
      </div></section>
      <Cta />
    </>
  );
}
