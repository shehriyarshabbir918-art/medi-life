import type { MetadataRoute } from "next";
import { siteConfig, navLinks, services, departments, posts } from "@/lib/siteConfig";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = siteConfig.url;
  const paths = [...navLinks.map((l) => l.href), "/appointment", "/faq",
    ...services.map((s) => `/services/${s.slug}`), ...departments.map((d) => `/departments/${d.slug}`), ...posts.map((p) => `/blog/${p.slug}`)];
  return paths.map((p) => ({ url: `${base}${p === "/" ? "" : p}`, lastModified: new Date() }));
}
