import type { Metadata } from "next";
import Link from "next/link";
import PageHeader from "@/components/PageHeader";
import ImagePlaceholder from "@/components/ImagePlaceholder";
import { posts } from "@/lib/siteConfig";

export const metadata: Metadata = { title: "Health & Medical Articles", description: "Health articles from Medi Life." };

export default function Blog() {
  return (
    <>
      <PageHeader title="Health & Medical Articles" text="Placeholder articles. Replace them with reviewed medical content." />
      <section className="section"><div className="container-x grid gap-6 md:grid-cols-3">
        {posts.map((p) => (
          <article key={p.slug} className="card flex flex-col">
            <ImagePlaceholder alt="" label="article image" className="mb-4 !min-h-[140px]" />
            <h2 className="text-lg font-bold">{p.title}</h2>
            <p className="mt-2 flex-1 text-sm text-ink/70">{p.excerpt}</p>
            <Link href={`/blog/${p.slug}`} className="btn-outline mt-4 self-start">Read article</Link>
          </article>
        ))}
      </div></section>
    </>
  );
}
