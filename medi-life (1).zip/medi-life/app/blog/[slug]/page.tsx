import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import PageHeader from "@/components/PageHeader";
import { posts } from "@/lib/siteConfig";

export function generateStaticParams() { return posts.map((p) => ({ slug: p.slug })); }
export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const p = posts.find((x) => x.slug === params.slug);
  return { title: p?.title ?? "Article", description: p?.excerpt };
}

export default function Post({ params }: { params: { slug: string } }) {
  const p = posts.find((x) => x.slug === params.slug);
  if (!p) notFound();
  return (
    <>
      <PageHeader title={p.title} />
      <article className="section"><div className="container-x max-w-3xl space-y-4">
        {p.body.map((t) => <p key={t} className="text-ink/80">{t}</p>)}
        <Link href="/blog" className="btn-outline mt-4">Back to articles</Link>
      </div></article>
    </>
  );
}
