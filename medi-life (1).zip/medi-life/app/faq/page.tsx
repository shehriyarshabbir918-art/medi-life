import type { Metadata } from "next";
import PageHeader from "@/components/PageHeader";
import { faqs } from "@/lib/siteConfig";

export const metadata: Metadata = { title: "FAQ", description: "Answers to common questions about Medi Life." };

export default function Faq() {
  return (
    <>
      <PageHeader title="Frequently Asked Questions" />
      <section className="section"><div className="container-x max-w-3xl space-y-3">
        {faqs.map((f) => (
          <details key={f.q} className="card !p-5">
            <summary className="cursor-pointer font-semibold">{f.q}</summary>
            <p className="mt-3 text-sm text-ink/75">{f.a}</p>
          </details>
        ))}
      </div></section>
    </>
  );
}
