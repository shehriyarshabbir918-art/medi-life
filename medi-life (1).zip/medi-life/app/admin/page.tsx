"use client";
import { useCallback, useEffect, useState } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase, isSupabaseConfigured } from "@/lib/supabase";

type Row = Record<string, string | null>;
type FieldDef = { key: string; label: string; area?: boolean };

const tabs = ["appointments", "contact_messages", "doctors", "services", "departments"] as const;
type Tab = (typeof tabs)[number];

const editable: Record<string, FieldDef[]> = {
  doctors: [{ key: "name", label: "Name" }, { key: "specialty", label: "Specialty" }, { key: "qualification", label: "Qualification" }, { key: "experience", label: "Experience" }, { key: "availability", label: "Availability" }, { key: "image_url", label: "Image URL" }, { key: "bio", label: "Bio", area: true }],
  services: [{ key: "name", label: "Name" }, { key: "slug", label: "Slug" }, { key: "icon", label: "Icon" }, { key: "description", label: "Description", area: true }],
  departments: [{ key: "name", label: "Name" }, { key: "slug", label: "Slug" }, { key: "image_url", label: "Image URL" }, { key: "description", label: "Description", area: true }],
};
const statuses: Record<string, string[]> = { appointments: ["pending", "confirmed", "completed", "cancelled"], contact_messages: ["new", "read", "replied"] };

export default function Admin() {
  const [session, setSession] = useState<Session | null>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setReady(true); });
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => data.subscription.unsubscribe();
  }, []);

  if (!isSupabaseConfigured) return <Box><p>Supabase is not configured. Add the keys to .env first.</p></Box>;
  if (!ready) return <Box><p>Loading...</p></Box>;
  if (!session) return <Login />;
  return <Dashboard email={session.user.email ?? ""} />;
}

function Box({ children }: { children: React.ReactNode }) { return <div className="container-x section"><div className="card mx-auto max-w-md">{children}</div></div>; }

function Login() {
  const [err, setErr] = useState("");
  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const { error } = await supabase.auth.signInWithPassword({ email: String(f.get("email")), password: String(f.get("password")) });
    if (error) setErr("Sign-in failed. Check your email and password.");
  }
  return (
    <Box>
      <h1 className="mb-4 text-2xl font-extrabold">Admin sign in</h1>
      <form onSubmit={onSubmit} className="space-y-4">
        <div><label htmlFor="email" className="label">Email</label><input id="email" name="email" type="email" required className="input" /></div>
        <div><label htmlFor="password" className="label">Password</label><input id="password" name="password" type="password" required className="input" /></div>
        {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
        <button className="btn-primary w-full" type="submit">Sign in</button>
      </form>
    </Box>
  );
}

function Dashboard({ email }: { email: string }) {
  const [tab, setTab] = useState<Tab>("appointments");
  const [rows, setRows] = useState<Row[]>([]);
  const [msg, setMsg] = useState("");

  const load = useCallback(async () => {
    const { data, error } = await supabase.from(tab).select("*").order("created_at", { ascending: false });
    if (error) { setMsg("Could not load data. Make sure your user is listed in admin_users (see README)."); setRows([]); } else { setMsg(""); setRows((data as Row[]) ?? []); }
  }, [tab]);
  useEffect(() => { load(); }, [load]);

  async function setStatus(id: string, status: string) { const { error } = await supabase.from(tab).update({ status }).eq("id", id); if (error) setMsg("Update failed."); else load(); }
  async function remove(id: string) { if (!confirm("Delete this record?")) return; const { error } = await supabase.from(tab).delete().eq("id", id); if (error) setMsg("Delete failed."); else load(); }
  async function add(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const payload: Record<string, string | null> = {};
    editable[tab].forEach((d) => { payload[d.key] = String(f.get(d.key) ?? "").trim() || null; });
    const { error } = await supabase.from(tab).insert(payload);
    if (error) setMsg("Could not save. Check required fields."); else { e.currentTarget.reset(); load(); }
  }

  const cols = rows[0] ? Object.keys(rows[0]).filter((k) => !["id", "bio", "message", "image_url"].includes(k)) : [];
  return (
    <div className="container-x section">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-3xl font-extrabold">Admin</h1>
        <div className="flex items-center gap-3 text-sm"><span className="text-ink/60">{email}</span><button className="btn-outline" onClick={() => supabase.auth.signOut()}>Sign out</button></div>
      </div>
      <div role="tablist" className="mb-6 flex flex-wrap gap-2">
        {tabs.map((t) => <button key={t} role="tab" aria-selected={tab === t} onClick={() => setTab(t)} className={`rounded-full px-4 py-2 text-sm font-semibold ${tab === t ? "bg-brand text-white" : "bg-brand-light text-brand"}`}>{t.replace("_", " ")}</button>)}
      </div>
      {msg && <p role="alert" className="mb-4 rounded-xl bg-red-50 p-3 text-sm text-red-700">{msg}</p>}
      {editable[tab] && (
        <form onSubmit={add} className="card mb-6 grid gap-3 sm:grid-cols-2">
          {editable[tab].map((d) => (<div key={d.key} className={d.area ? "sm:col-span-2" : ""}><label className="label" htmlFor={`f-${d.key}`}>{d.label}</label>{d.area ? <textarea id={`f-${d.key}`} name={d.key} className="input" rows={2} /> : <input id={`f-${d.key}`} name={d.key} className="input" />}</div>))}
          <div className="sm:col-span-2"><button className="btn-primary" type="submit">Add to {tab}</button></div>
        </form>
      )}
      <div className="overflow-x-auto rounded-2xl border border-brand/10">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead className="bg-brand-light"><tr>{cols.map((c) => <th key={c} className="px-3 py-3">{c.replace("_", " ")}</th>)}<th className="px-3 py-3">Actions</th></tr></thead>
          <tbody>
            {rows.length === 0 && <tr><td className="px-3 py-6 text-ink/60" colSpan={cols.length + 1}>No records yet.</td></tr>}
            {rows.map((r) => (
              <tr key={r.id} className="border-t border-brand/10 align-top">
                {cols.map((c) => <td key={c} className="px-3 py-3">{c === "status" && statuses[tab] ? (
                  <select aria-label="Status" className="input !py-1" value={r.status ?? ""} onChange={(e) => setStatus(r.id as string, e.target.value)}>{statuses[tab].map((s) => <option key={s}>{s}</option>)}</select>
                ) : String(r[c] ?? "")}</td>)}
                <td className="px-3 py-3"><button className="text-red-700 underline" onClick={() => remove(r.id as string)}>Delete</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
