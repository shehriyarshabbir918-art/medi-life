import type { Metadata } from "next";
import { Phone, Mail, MapPin, Clock, Siren } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import ContactForm from "@/components/ContactForm";
import { siteConfig } from "@/lib/siteConfig";

export const metadata: Metadata = { title: "Contact Us", description: "Contact Medi Life." };

export default function Contact() {
  const rows = [
    { Icon: Phone, label: "Phone", value: siteConfig.phone },
    { Icon: Mail, label: "Email", value: siteConfig.email },
    { Icon: MapPin, label: "Address", value: siteConfig.address },
    { Icon: Siren, label: "Emergency", value: siteConfig.emergency },
  ];
  return (
    <>
      <PageHeader title="Contact Us" text="We are happy to answer your questions." />
      <section className="section"><div className="container-x grid gap-8 lg:grid-cols-5">
        <div className="space-y-4 lg:col-span-2">
          {rows.map(({ Icon, label, value }) => (
            <div key={label} className="card flex gap-4 !p-5"><span className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-brand-light text-brand"><Icon size={20} aria-hidden="true" /></span><div><h2 className="text-sm font-bold">{label}</h2><p className="text-sm text-ink/70">{value}</p></div></div>
          ))}
          <div className="card !p-5"><h2 className="mb-2 flex items-center gap-2 text-sm font-bold"><Clock size={18} aria-hidden="true" /> Opening Hours</h2>
            <ul className="space-y-1 text-sm text-ink/70">{siteConfig.hours.map((h) => <li key={h.day} className="flex justify-between gap-4"><span>{h.day}</span><span>{h.time}</span></li>)}</ul></div>
        </div>
        <div className="lg:col-span-3"><ContactForm /></div>
      </div></section>
    </>
  );
}
