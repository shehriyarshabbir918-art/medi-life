import type { Metadata } from "next";
import PageHeader from "@/components/PageHeader";
import DoctorCard from "@/components/DoctorCard";
import { supabase, isSupabaseConfigured } from "@/lib/supabase";
import { sampleDoctors, type Doctor } from "@/lib/siteConfig";

export const metadata: Metadata = { title: "Our Doctors", description: "Meet the Medi Life medical team." };
export const revalidate = 60;

// Real doctors come from the Supabase "doctors" table (add them in /admin).
// If the table is empty or Supabase is not set up, sample cards are shown.
async function getDoctors(): Promise<{ list: Doctor[]; sample: boolean }> {
  if (isSupabaseConfigured) {
    const { data } = await supabase.from("doctors").select("id,name,specialty,qualification,experience,bio,image_url,availability").order("name");
    if (data && data.length > 0) return { list: data as Doctor[], sample: false };
  }
  return { list: sampleDoctors, sample: true };
}

export default async function Doctors() {
  const { list, sample } = await getDoctors();
  return (
    <>
      <PageHeader title="Our Medical Team" text="Experienced professionals dedicated to your care." />
      <section className="section"><div className="container-x">
        {sample && <p className="mb-8 rounded-2xl bg-brand-light p-4 text-sm text-ink/70">These are sample cards, not real doctors. Add real doctors in the admin area.</p>}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">{list.map((d) => <DoctorCard key={d.id} doctor={d} />)}</div>
      </div></section>
    </>
  );
}
