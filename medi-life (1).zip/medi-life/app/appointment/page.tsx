import type { Metadata } from "next";
import { Suspense } from "react";
import PageHeader from "@/components/PageHeader";
import AppointmentForm from "@/components/AppointmentForm";

export const metadata: Metadata = { title: "Book an Appointment", description: "Request an appointment with Medi Life." };

export default function Appointment() {
  return (
    <>
      <PageHeader title="Book an Appointment" text="Tell us what you need. We will confirm your visit by phone or email." />
      <section className="section"><div className="container-x max-w-3xl">
        <Suspense fallback={<p>Loading form...</p>}><AppointmentForm /></Suspense>
        <p className="mt-4 text-sm text-ink/60">For a medical emergency, do not use this form. Call your local emergency number.</p>
      </div></section>
    </>
  );
}
