import type { Metadata } from "next";
import PageHeader from "@/components/PageHeader";
import ImagePlaceholder from "@/components/ImagePlaceholder";
import Cta from "@/components/Cta";
import { values } from "@/lib/siteConfig";

export const metadata: Metadata = { title: "About Us", description: "Learn about Medi Life, our mission, vision and values." };

export default function About() {
  return (
    <>
      <PageHeader title="About Medi Life" text="A modern healthcare organization focused on accessible, compassionate and high-quality care." />
      <section className="section">
        <div className="container-x grid items-center gap-10 lg:grid-cols-2">
          <div>
            <h2 className="text-3xl font-extrabold">Our Story</h2>
            <p className="mt-4 text-ink/75">Medi Life is a modern healthcare organization focused on accessible, compassionate and high-quality healthcare. We put patients at the center of every decision, from the first call to follow-up care.</p>
            <p className="mt-4 rounded-2xl bg-brand-light p-4 text-sm text-ink/70">Placeholder: add founding year, locations, team size and other verified facts here once confirmed.</p>
          </div>
          <ImagePlaceholder alt="Medi Life facility" label="about photo (e.g. /images/about.jpg)" />
        </div>
      </section>
      <section className="section bg-mist">
        <div className="container-x grid gap-6 md:grid-cols-2">
          <div className="card"><h2 className="text-2xl font-extrabold">Our Mission</h2><p className="mt-3 text-ink/75">To provide compassionate, accessible and high-quality healthcare while putting patients at the center of everything we do.</p></div>
          <div className="card"><h2 className="text-2xl font-extrabold">Our Vision</h2><p className="mt-3 text-ink/75">To contribute to a healthier future through trusted healthcare, innovation and patient-centered service.</p></div>
        </div>
      </section>
      <section className="section">
        <div className="container-x">
          <h2 className="text-3xl font-extrabold">Our Values</h2>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {values.map((v) => (<div key={v.title} className="card"><h3 className="font-bold text-brand">{v.title}</h3><p className="mt-2 text-sm text-ink/70">{v.text}</p></div>))}
          </div>
        </div>
      </section>
      <Cta />
    </>
  );
}
