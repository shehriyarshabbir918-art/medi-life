-- Medi Life database schema. Run this in Supabase: SQL Editor > New query > Run.
create extension if not exists "pgcrypto";

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.admin_users where user_id = auth.uid());
$$;

create table if not exists public.departments (
  id uuid primary key default gen_random_uuid(),
  name text not null, slug text not null unique, description text, image_url text,
  active boolean not null default true, created_at timestamptz not null default now()
);
create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  name text not null, slug text not null unique, description text, icon text,
  active boolean not null default true, created_at timestamptz not null default now()
);
create table if not exists public.doctors (
  id uuid primary key default gen_random_uuid(),
  name text not null, specialty text, qualification text, experience text, bio text,
  image_url text, availability text, created_at timestamptz not null default now()
);
create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  patient_name text not null check (char_length(patient_name) between 1 and 120),
  email text not null check (email ~* '^\S+@\S+\.\S+$'),
  phone text not null check (char_length(phone) between 7 and 30),
  appointment_date date not null, appointment_time text not null, department text not null,
  doctor_id uuid references public.doctors(id) on delete set null,
  message text check (message is null or char_length(message) <= 2000),
  status text not null default 'pending' check (status in ('pending','confirmed','completed','cancelled')),
  created_at timestamptz not null default now()
);
create table if not exists public.contact_messages (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 120),
  email text not null check (email ~* '^\S+@\S+\.\S+$'),
  phone text, subject text,
  message text not null check (char_length(message) between 10 and 3000),
  status text not null default 'new' check (status in ('new','read','replied')),
  created_at timestamptz not null default now()
);

create index if not exists appointments_status_idx on public.appointments (status, created_at desc);
create index if not exists appointments_date_idx on public.appointments (appointment_date);
create index if not exists appointments_doctor_idx on public.appointments (doctor_id);
create index if not exists contact_status_idx on public.contact_messages (status, created_at desc);
create index if not exists doctors_specialty_idx on public.doctors (specialty);

alter table public.admin_users enable row level security;
alter table public.departments enable row level security;
alter table public.services enable row level security;
alter table public.doctors enable row level security;
alter table public.appointments enable row level security;
alter table public.contact_messages enable row level security;

-- Public site content: anyone can read, only admins can change.
create policy "public read doctors" on public.doctors for select using (true);
create policy "public read services" on public.services for select using (active or public.is_admin());
create policy "public read departments" on public.departments for select using (active or public.is_admin());
create policy "admin write doctors" on public.doctors for all using (public.is_admin()) with check (public.is_admin());
create policy "admin write services" on public.services for all using (public.is_admin()) with check (public.is_admin());
create policy "admin write departments" on public.departments for all using (public.is_admin()) with check (public.is_admin());

-- Visitors can only INSERT forms (status forced to the default); only admins can read or change them.
create policy "anyone can book" on public.appointments for insert to anon, authenticated with check (status = 'pending');
create policy "admin read appointments" on public.appointments for select using (public.is_admin());
create policy "admin update appointments" on public.appointments for update using (public.is_admin()) with check (public.is_admin());
create policy "admin delete appointments" on public.appointments for delete using (public.is_admin());
create policy "anyone can contact" on public.contact_messages for insert to anon, authenticated with check (status = 'new');
create policy "admin read messages" on public.contact_messages for select using (public.is_admin());
create policy "admin update messages" on public.contact_messages for update using (public.is_admin()) with check (public.is_admin());
create policy "admin delete messages" on public.contact_messages for delete using (public.is_admin());
create policy "admins read admin_users" on public.admin_users for select using (user_id = auth.uid());

-- AFTER creating your admin user in Supabase > Authentication > Users, run:
-- insert into public.admin_users (user_id) select id from auth.users where email = 'YOUR_ADMIN_EMAIL';
