# Medi Life website

Next.js 14 + TypeScript + Tailwind CSS + Supabase. GitHub- and Railway-ready.

## 1. Run locally
```bash
npm install
cp .env.example .env.local   # then fill in the values
npm run dev                  # http://localhost:3000
```
Production build:
```bash
npm run build
npm start
```

## 2. Set up Supabase (the backend)
1. Create a project at supabase.com.
2. SQL Editor > New query > paste `supabase/schema.sql` > Run.
3. Project Settings > API: copy **Project URL** into `NEXT_PUBLIC_SUPABASE_URL` and the **anon public** key into `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
4. Authentication > Users > Add user (your admin email + a strong password).
5. Run in the SQL Editor: `insert into public.admin_users (user_id) select id from auth.users where email = 'YOUR_ADMIN_EMAIL';`
6. Open `/admin`, sign in, and add doctors, services and departments.

Only the public anon key is used in the browser. Row Level Security lets visitors submit forms only; just admins can read them. Never use the service-role key in this project.

## 3. Push to GitHub
```bash
git init && git add . && git commit -m "Medi Life website"
git branch -M main
git remote add origin https://github.com/YOUR_USER/medi-life.git
git push -u origin main
```

## 4. Deploy on Railway
1. Push the project to GitHub.
2. Railway > New Project > Deploy from GitHub repo > pick `medi-life`.
3. Variables tab: add `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `NEXT_PUBLIC_SITE_URL` (your live URL).
4. Deploy (Railway runs `npm run build` and `npm start`).
5. Settings > Networking > Generate Domain, or add your custom domain.
Set the variables before the first build: `NEXT_PUBLIC_` values are baked in at build time.

## 5. What to replace before launch
- `lib/siteConfig.ts`: phone, email, address, emergency number, opening hours, social links, statistics, services, departments, FAQ, blog posts. Everything reading `ADD_...` or `PLACEHOLDER` is not real data.
- Pictures: put photos in `public/images/` and pass the path to `ImagePlaceholder` (home hero, about page). Blank dashed boxes mark every spot.
- Logo: replace `public/logo.svg`, `public/logo-light.svg`, `public/favicon.svg`.
- Doctors: add real ones in `/admin` (sample cards disappear automatically).
- Appointment time slots: `components/AppointmentForm.tsx` (`times`).
- Quality page: add certifications only once verified.
- Privacy policy / terms: add your own.
