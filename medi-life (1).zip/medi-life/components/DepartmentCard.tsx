import Link from "next/link";
import Icon from "./Icon";
import type { Department } from "@/lib/siteConfig";

export default function DepartmentCard({ dept }: { dept: Department }) {
  return (
    <article className="card flex h-full flex-col">
      <span className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-mint/10 text-mint-dark"><Icon name={dept.icon} size={24} /></span>
      <h3 className="text-lg font-bold">{dept.name}</h3>
      <p className="mt-2 text-sm text-ink/70">{dept.description}</p>
      <ul className="mt-3 flex-1 list-disc space-y-1 pl-5 text-sm text-ink/80">{dept.services.map((s) => <li key={s}>{s}</li>)}</ul>
      <Link href={`/departments/${dept.slug}`} className="btn-outline mt-5 self-start">View Department</Link>
    </article>
  );
}
