import Link from "next/link";
import { UserRound } from "lucide-react";
import Image from "next/image";
import type { Doctor } from "@/lib/siteConfig";

export default function DoctorCard({ doctor }: { doctor: Doctor }) {
  return (
    <article className="card flex h-full flex-col">
      <div className="mb-4 flex h-48 items-center justify-center overflow-hidden rounded-2xl bg-brand-light text-brand/40">
        {doctor.image_url ? <Image src={doctor.image_url} alt={`Photo of ${doctor.name}`} width={400} height={300} className="h-full w-full object-cover" /> : <UserRound size={64} aria-label="Add doctor photo here" />}
      </div>
      <h3 className="text-lg font-bold">{doctor.name}</h3>
      <p className="text-sm font-semibold text-brand">{doctor.specialty}</p>
      <dl className="mt-3 flex-1 space-y-1 text-sm text-ink/75">
        <div><dt className="inline font-medium">Qualification: </dt><dd className="inline">{doctor.qualification}</dd></div>
        <div><dt className="inline font-medium">Experience: </dt><dd className="inline">{doctor.experience}</dd></div>
        <div><dt className="inline font-medium">Availability: </dt><dd className="inline">{doctor.availability}</dd></div>
      </dl>
      <Link href={`/appointment?doctor=${doctor.id}`} className="btn-primary mt-5 self-start">Book Appointment</Link>
    </article>
  );
}
