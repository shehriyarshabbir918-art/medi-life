import Link from "next/link";
import { Facebook, Instagram, Linkedin, Youtube, Phone, Mail, MapPin } from "lucide-react";
import Logo from "./Logo";
import { siteConfig } from "@/lib/siteConfig";

const socials = [
  { key: "facebook", label: "Facebook", Icon: Facebook },
  { key: "instagram", label: "Instagram", Icon: Instagram },
  { key: "linkedin", label: "LinkedIn", Icon: Linkedin },
  { key: "youtube", label: "YouTube", Icon: Youtube },
] as const;

export default function Footer() {
  const live = socials.filter((s) => siteConfig.social[s.key] && siteConfig.social[s.key] !== "#");
  return (
    <footer className="bg-ink text-white">
      <div className="container-x grid gap-10 py-14 md:grid-cols-4">
        <div className="md:col-span-1">
          <Logo light />
          <p className="mt-4 text-sm text-white/70">{siteConfig.description}</p>
          {live.length > 0 && (
            <div className="mt-4 flex gap-3">
              {live.map(({ key, label, Icon }) => (
                <a key={key} href={siteConfig.social[key]} aria-label={label} target="_blank" rel="noopener noreferrer" className="rounded-full bg-white/10 p-2 hover:bg-white/20"><Icon size={18} /></a>
              ))}
            </div>
          )}
        </div>
        <FooterCol title="Quick Links" links={[["/", "Home"], ["/about", "About"], ["/services", "Services"], ["/doctors", "Doctors"], ["/contact", "Contact"]]} />
        <FooterCol title="Services" links={[["/services/general-medicine", "General Medicine"], ["/services/diagnostics", "Diagnostics"], ["/departments", "Specialist Care"], ["/services/preventive-healthcare", "Preventive Care"]]} />
        <div>
          <h2 className="mb-4 font-semibold">Contact</h2>
          <ul className="space-y-3 text-sm text-white/70">
            <li className="flex gap-2"><Phone size={16} className="mt-0.5 shrink-0" /> {siteConfig.phone}</li>
            <li className="flex gap-2"><Mail size={16} className="mt-0.5 shrink-0" /> {siteConfig.email}</li>
            <li className="flex gap-2"><MapPin size={16} className="mt-0.5 shrink-0" /> {siteConfig.address}</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/10 py-5 text-center text-sm text-white/60">© 2026 Medi Life. All rights reserved.</div>
    </footer>
  );
}

function FooterCol({ title, links }: { title: string; links: string[][] }) {
  return (
    <div>
      <h2 className="mb-4 font-semibold">{title}</h2>
      <ul className="space-y-2 text-sm text-white/70">
        {links.map(([href, label]) => (<li key={href + label}><Link href={href} className="hover:text-white">{label}</Link></li>))}
      </ul>
    </div>
  );
}
