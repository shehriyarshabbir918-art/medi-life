import Link from "next/link";
import Icon from "./Icon";
import type { Service } from "@/lib/siteConfig";

export default function ServiceCard({ service }: { service: Service }) {
  return (
    <article className="card flex h-full flex-col transition-transform duration-200 hover:-translate-y-1">
      <span className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-light text-brand"><Icon name={service.icon} size={24} /></span>
      <h3 className="text-lg font-bold">{service.name}</h3>
      <p className="mt-2 flex-1 text-sm text-ink/70">{service.description}</p>
      <Link href={`/services/${service.slug}`} className="btn-outline mt-5 self-start">Learn More</Link>
    </article>
  );
}
