"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import Logo from "./Logo";
import { navLinks } from "@/lib/siteConfig";

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const path = usePathname();
  return (
    <header className="sticky top-0 z-50 border-b border-brand/10 bg-white/90 backdrop-blur">
      <div className="container-x flex h-[72px] items-center justify-between gap-4">
        <Logo />
        <nav aria-label="Main" className="hidden items-center gap-1 lg:flex">
          {navLinks.map((l) => (
            <Link key={l.href} href={l.href} aria-current={path === l.href ? "page" : undefined}
              className={`rounded-full px-3 py-2 text-sm font-medium transition-colors hover:bg-brand-light hover:text-brand ${path === l.href ? "bg-brand-light text-brand" : ""}`}>{l.label}</Link>
          ))}
        </nav>
        <Link href="/appointment" className="btn-primary hidden lg:inline-flex">Book Appointment</Link>
        <button className="rounded-lg p-2 lg:hidden" onClick={() => setOpen(!open)} aria-expanded={open} aria-controls="mobile-nav" aria-label={open ? "Close menu" : "Open menu"}>
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <nav id="mobile-nav" aria-label="Mobile" className="border-t border-brand/10 bg-white lg:hidden">
          <div className="container-x flex flex-col gap-1 py-4">
            {navLinks.map((l) => (
              <Link key={l.href} href={l.href} onClick={() => setOpen(false)} className="rounded-xl px-3 py-3 font-medium hover:bg-brand-light">{l.label}</Link>
            ))}
            <Link href="/appointment" onClick={() => setOpen(false)} className="btn-primary mt-2">Book Appointment</Link>
          </div>
        </nav>
      )}
    </header>
  );
}
