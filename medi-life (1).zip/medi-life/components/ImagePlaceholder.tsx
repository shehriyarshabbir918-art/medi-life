import Image from "next/image";

// Drop a photo into public/images and pass its path as `src`.
// Until then, a labelled blank space is shown so the layout is ready.
export default function ImagePlaceholder({ src, alt, label, className = "" }: { src?: string; alt: string; label: string; className?: string }) {
  if (src) return <Image src={src} alt={alt} width={900} height={700} className={`h-full w-full rounded-3xl object-cover ${className}`} />;
  return (
    <div role="img" aria-label={alt} className={`flex min-h-[220px] w-full items-center justify-center rounded-3xl border-2 border-dashed border-brand/30 bg-brand-light p-6 text-center text-sm text-ink/60 ${className}`}>
      Add image here: {label}
    </div>
  );
}
