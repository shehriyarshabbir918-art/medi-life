"use client";
import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { Field, Status } from "./FormField";
import { supabase, isSupabaseConfigured } from "@/lib/supabase";
import { departments } from "@/lib/siteConfig";

type Doc = { id: string; name: string; specialty: string };
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const times = ["Morning (9am - 12pm)", "Afternoon (12pm - 4pm)", "Evening (4pm - 8pm)"]; // edit to match real hours

export default function AppointmentForm() {
  const params = useSearchParams();
  const preselect = params.get("doctor") ?? "";
  const [docs, setDocs] = useState<Doc[]>([]);
  const [state, setState] = useState<{ type: "idle" | "loading" | "success" | "error"; message?: string }>({ type: "idle" });
  const today = new Date().toISOString().split("T")[0];

  useEffect(() => {
    if (!isSupabaseConfigured) return;
    supabase.from("doctors").select("id,name,specialty").order("name").then(({ data }) => setDocs((data as Doc[]) ?? []));
  }, []);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const f = new FormData(form);
    const email = String(f.get("email") ?? "").trim();
    const phone = String(f.get("phone") ?? "").trim();
    const date = String(f.get("date") ?? "");
    if (!/^\S+@\S+\.\S+$/.test(email)) return setState({ type: "error", message: "Enter a valid email address." });
    if (phone.replace(/\D/g, "").length < 7) return setState({ type: "error", message: "Enter a valid phone number." });
    if (!date || date < today) return setState({ type: "error", message: "Choose today or a future date." });
    if (!isSupabaseConfigured) return setState({ type: "error", message: "Booking is not connected yet. Add the Supabase keys in .env." });
    setState({ type: "loading" });
    const doctor = String(f.get("doctor") ?? "");
    const { error } = await supabase.from("appointments").insert({
      patient_name: String(f.get("name") ?? "").trim(), email, phone, appointment_date: date,
      appointment_time: String(f.get("time") ?? ""), department: String(f.get("department") ?? ""),
      doctor_id: uuid.test(doctor) ? doctor : null, message: String(f.get("message") ?? "").trim() || null,
    });
    if (error) return setState({ type: "error", message: "We could not book your appointment. Please check your details and try again." });
    form.reset();
    setState({ type: "success", message: "Request received. Our team will contact you to confirm your appointment." });
  }

  return (
    <form onSubmit={onSubmit} className="card space-y-4" noValidate>
      <div className="grid gap-4 sm:grid-cols-2"><Field label="Full Name" name="name" required /><Field label="Email" name="email" type="email" required /></div>
      <div className="grid gap-4 sm:grid-cols-2"><Field label="Phone" name="phone" type="tel" required />
        <div><label htmlFor="date" className="label">Date <span aria-hidden="true">*</span></label><input id="date" name="date" type="date" min={today} required className="input" /></div></div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div><label htmlFor="time" className="label">Preferred Time <span aria-hidden="true">*</span></label>
          <select id="time" name="time" required className="input" defaultValue=""><option value="" disabled>Select a time</option>{times.map((t) => <option key={t}>{t}</option>)}</select></div>
        <div><label htmlFor="department" className="label">Department <span aria-hidden="true">*</span></label>
          <select id="department" name="department" required className="input" defaultValue=""><option value="" disabled>Select a department</option>{departments.map((d) => <option key={d.slug}>{d.name}</option>)}</select></div>
      </div>
      <div><label htmlFor="doctor" className="label">Doctor (optional)</label>
        <select id="doctor" name="doctor" className="input" defaultValue={uuid.test(preselect) ? preselect : ""}><option value="">No preference</option>{docs.map((d) => <option key={d.id} value={d.id}>{d.name} - {d.specialty}</option>)}</select></div>
      <div><label htmlFor="message" className="label">Message</label><textarea id="message" name="message" rows={4} className="input" /></div>
      <Status state={state} />
      <button type="submit" className="btn-primary" disabled={state.type === "loading"}>{state.type === "loading" ? "Booking..." : "Book appointment"}</button>
    </form>
  );
}
