import { Stethoscope, HeartPulse, Flower2, Baby, Bone, Sparkles, ScanLine, FlaskConical, Siren, ShieldCheck, MessageSquareHeart, type LucideProps } from "lucide-react";

const map = { stethoscope: Stethoscope, heart: HeartPulse, flower: Flower2, baby: Baby, bone: Bone, sparkles: Sparkles, scan: ScanLine, flask: FlaskConical, siren: Siren, shield: ShieldCheck, message: MessageSquareHeart };

export default function Icon({ name, ...props }: { name: string } & LucideProps) {
  const C = map[name as keyof typeof map] ?? Stethoscope;
  return <C aria-hidden="true" {...props} />;
}
