import Link from "next/link";

export default function Cta() {
  return (
    <section className="section">
      <div className="container-x">
        <div className="rounded-[2rem] bg-brand px-6 py-14 text-center text-white sm:px-12">
          <h2 className="text-3xl font-extrabold sm:text-4xl">Your Health Is Our Priority</h2>
          <p className="mx-auto mt-3 max-w-xl text-white/85">Choose a department and a time that suits you. Our team will confirm your visit.</p>
          <Link href="/appointment" className="btn mt-7 bg-white text-brand hover:bg-brand-light">Book an Appointment</Link>
        </div>
      </div>
    </section>
  );
}
