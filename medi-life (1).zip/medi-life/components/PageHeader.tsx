export default function PageHeader({ title, text }: { title: string; text?: string }) {
  return (
    <section className="bg-gradient-to-b from-brand-light to-white">
      <div className="container-x py-14 sm:py-20">
        <h1 className="max-w-3xl text-4xl font-extrabold tracking-tight sm:text-5xl">{title}</h1>
        {text && <p className="mt-4 max-w-2xl text-lg text-ink/70">{text}</p>}
      </div>
    </section>
  );
}
