import Link from "next/link";

// Swap public/logo.svg and public/logo-light.svg for your official logo files.
export default function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link href="/" aria-label="Medi Life home" className="inline-block">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={light ? "/logo-light.svg" : "/logo.svg"} alt="Medi Life" width={160} height={41} className="h-10 w-auto" />
    </Link>
  );
}
