"use client";
import { useState } from "react";
import { Field, Status } from "./FormField";
import { supabase, isSupabaseConfigured } from "@/lib/supabase";

export default function ContactForm() {
  const [state, setState] = useState<{ type: "idle" | "loading" | "success" | "error"; message?: string }>({ type: "idle" });

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const f = new FormData(form);
    const email = String(f.get("email") ?? "").trim();
    const message = String(f.get("message") ?? "").trim();
    if (!/^\S+@\S+\.\S+$/.test(email)) return setState({ type: "error", message: "Enter a valid email address." });
    if (message.length < 10) return setState({ type: "error", message: "Write a message of at least 10 characters." });
    if (!isSupabaseConfigured) return setState({ type: "error", message: "The form is not connected yet. Add the Supabase keys in .env." });
    setState({ type: "loading" });
    const { error } = await supabase.from("contact_messages").insert({
      name: String(f.get("name") ?? "").trim(), email, phone: String(f.get("phone") ?? "").trim() || null,
      subject: String(f.get("subject") ?? "").trim() || null, message,
    });
    if (error) return setState({ type: "error", message: "We could not send your message. Please try again in a moment." });
    form.reset();
    setState({ type: "success", message: "Thank you. Your message has been sent and our team will reply soon." });
  }

  return (
    <form onSubmit={onSubmit} className="card space-y-4" noValidate>
      <div className="grid gap-4 sm:grid-cols-2"><Field label="Name" name="name" required /><Field label="Email" name="email" type="email" required /></div>
      <div className="grid gap-4 sm:grid-cols-2"><Field label="Phone" name="phone" type="tel" /><Field label="Subject" name="subject" /></div>
      <div><label htmlFor="message" className="label">Message <span aria-hidden="true">*</span></label><textarea id="message" name="message" rows={5} required className="input" /></div>
      <Status state={state} />
      <button type="submit" className="btn-primary" disabled={state.type === "loading"}>{state.type === "loading" ? "Sending..." : "Send message"}</button>
    </form>
  );
}
