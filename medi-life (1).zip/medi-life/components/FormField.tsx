export function Field({ label, name, type = "text", required, placeholder }: { label: string; name: string; type?: string; required?: boolean; placeholder?: string }) {
  return (
    <div>
      <label htmlFor={name} className="label">{label}{required && <span aria-hidden="true"> *</span>}</label>
      <input id={name} name={name} type={type} required={required} placeholder={placeholder} className="input" />
    </div>
  );
}

export function Status({ state }: { state: { type: "idle" | "loading" | "success" | "error"; message?: string } }) {
  if (state.type === "success") return <p role="status" className="rounded-xl bg-mint/10 p-4 text-sm font-medium text-mint-dark">{state.message}</p>;
  if (state.type === "error") return <p role="alert" className="rounded-xl bg-red-50 p-4 text-sm font-medium text-red-700">{state.message}</p>;
  return null;
}
